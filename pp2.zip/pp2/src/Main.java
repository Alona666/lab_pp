import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.locks.ReentrantLock;

class P1DiningPhilosophersHomework {

    private enum ReleaseOrder {
        REVERSE,
        SAME
    }

    private static final class Fork {
        final int id;
        final ReentrantLock lock = new ReentrantLock();

        Fork(int id) {
            this.id = id;
        }
    }

    private static final class Table {
        private final Fork[] forks;
        private final AtomicIntegerArray forkUsers;
        private final AtomicBoolean conflictDetected = new AtomicBoolean();

        Table(int philosopherCount) {
            forks = new Fork[philosopherCount];
            for (int id = 0; id < philosopherCount; id++) {
                forks[id] = new Fork(id);
            }
            forkUsers = new AtomicIntegerArray(philosopherCount);
        }

        void eat(int philosopherId, ReleaseOrder releaseOrder) {
            Fork left = forks[philosopherId];
            Fork right = forks[(philosopherId + 1) % forks.length];

            // Глобальный порядок: сначала меньший id, потом больший.
            Fork first = left.id < right.id ? left : right;
            Fork second = left.id < right.id ? right : left;

            first.lock.lock();
            try {
                second.lock.lock();
                try {
                    eatWithBothForks(first, second);
                } finally {
                    if (releaseOrder == ReleaseOrder.SAME) {
                        // Освобождаем в том же порядке, в каком брали.
                        first.lock.unlock();
                        second.lock.unlock();
                    } else {
                        // Освобождаем в обратном порядке.
                        second.lock.unlock();
                        first.lock.unlock();
                    }
                }
            } finally {
                // Защита на случай, если second.lock.lock() не выполнился.
                if (second.lock.isHeldByCurrentThread()) {
                    second.lock.unlock();
                }
                if (first.lock.isHeldByCurrentThread()) {
                    first.lock.unlock();
                }
            }
        }

        private void eatWithBothForks(Fork a, Fork b) {
            int usersA = forkUsers.incrementAndGet(a.id);
            int usersB = forkUsers.incrementAndGet(b.id);

            if (usersA != 1 || usersB != 1) {
                conflictDetected.set(true);
            }

            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                forkUsers.decrementAndGet(b.id);
                forkUsers.decrementAndGet(a.id);
            }
        }
    }

    public static void main(String[] args) throws Exception {
        run(ReleaseOrder.REVERSE);
        run(ReleaseOrder.SAME);
    }

    private static void run(ReleaseOrder order) throws Exception {
        int philosopherCount = 5;
        int mealsPerPhilosopher = 100;

        Table table = new Table(philosopherCount);
        ExecutorService pool = Executors.newFixedThreadPool(philosopherCount);
        List<Future<Integer>> results = new ArrayList<>();

        try {
            for (int philosopher = 0; philosopher < philosopherCount; philosopher++) {
                int philosopherId = philosopher;

                results.add(pool.submit(() -> {
                    int meals = 0;

                    while (meals < mealsPerPhilosopher) {
                        table.eat(philosopherId, order);
                        meals++;
                        Thread.yield();
                    }

                    return meals;
                }));
            }

            for (int philosopher = 0; philosopher < philosopherCount; philosopher++) {
                int meals = results.get(philosopher).get(10, TimeUnit.SECONDS);

                if (meals != mealsPerPhilosopher) {
                    throw new AssertionError(
                            "Philosopher " + philosopher + " ate " + meals + " times"
                    );
                }
            }
        } catch (TimeoutException e) {
            throw new AssertionError("Possible deadlock, order=" + order, e);
        } finally {
            pool.shutdownNow();
            try {
                pool.awaitTermination(2, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        if (table.conflictDetected.get()) {
            throw new AssertionError("Two philosophers used the same fork, order=" + order);
        }

        System.out.println(
                "OK: every philosopher ate " + mealsPerPhilosopher +
                        " times, no deadlock detected, release order = " + order
        );
    }
}

/*
1.Можно ли в таком случае организовать взаимную блокировку?
Нет, если все потоки действительно берут ресурсы строго по одному глобальному полному порядку, взаимная блокировка невозможна.
2.Можно ли организовать взаимную блокировку, если отдавать ресурсы в том-же порядке, в каком мы их берём?
Нет, сам порядок освобождения ресурсов не влияет на возникновение deadlock.
Можно освобождать и в обратном порядке, и в том же порядке, в котором брали, — deadlock не появится, пока сохраняется главное правило: нельзя запрашивать более “низкий” ресурс, удерживая более “высокий”.
 */