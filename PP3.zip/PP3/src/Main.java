import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public class Main {

    private static final class Result {
        final boolean[][] inside;
        final long insideCount;
        final int threadsUsed;

        Result(boolean[][] inside, long insideCount, int threadsUsed) {
            this.inside = inside;
            this.insideCount = insideCount;
            this.threadsUsed = threadsUsed;
        }
    }

    public static void main(String[] args) throws Exception {
        int width = 800;
        int height = 600;
        int maxIterations = 1000;

        // Количество потоков по числу доступных ядер CPU.
        int threads = Math.max(1, Runtime.getRuntime().availableProcessors());

        long startNs = System.nanoTime();

        Result result = compute(width, height, maxIterations, threads);

        long elapsedMs = (System.nanoTime() - startNs) / 1_000_000L;
        long totalPixels = (long) width * height;

        // Никакой картинки не рисуем, только статистику.
        System.out.println("Resolution: " + width + "x" + height);
        System.out.println("Threads: " + result.threadsUsed);
        System.out.println("Max iterations: " + maxIterations);
        System.out.println("Total pixels: " + totalPixels);
        System.out.println("Inside Mandelbrot: " + result.insideCount);
        System.out.println("Outside Mandelbrot: " + (totalPixels - result.insideCount));
        System.out.println("Time: " + elapsedMs + " ms");

        // Если нужно проверить конкретный пиксель:
        // boolean pixelInside = result.inside[y][x];
    }

    private static Result compute(
            int width,
            int height,
            int maxIterations,
            int threads
    ) throws InterruptedException, ExecutionException {

        if (width <= 0) {
            throw new IllegalArgumentException("width must be positive");
        }

        if (height <= 0) {
            throw new IllegalArgumentException("height must be positive");
        }

        if (maxIterations < 0) {
            throw new IllegalArgumentException("maxIterations must be non-negative");
        }

        // inside[y][x] == true, если пиксель принадлежит множеству Мандельброта.
        boolean[][] inside = new boolean[height][width];

        // Атомарный счётчик, чтобы несколько потоков могли безопасно увеличивать количество.
        AtomicLong insideCount = new AtomicLong();

        ExecutorService pool = Executors.newFixedThreadPool(threads);

        try {
            /*
             * Координатная область:
             * Обычно множество Мандельброта хорошо смотрится примерно в окне:
             * real: [-2.0, 1.0]
             * imag: [-1.5, 1.5]
             *
             * Здесь центр выбран в -0.5 по действительной оси,
             * ширина окна 3.0, высота подстраивается под пропорции экрана.
             */
            final double aspect = (double) height / width;
            final double spanX = 3.0;
            final double spanY = spanX * aspect;
            final double centerX = -0.5;
            final double centerY = 0.0;

            /*
             * Предвычисляем действительные части cr для всех столбцов.
             * Это не обязательно, но немного ускоряет внутренний цикл.
             */
            final double[] crValues = new double[width];
            for (int x = 0; x < width; x++) {
                crValues[x] = centerX + ((x - width / 2.0) * spanX / width);
            }

            /*
             * Разбиваем строки между потоками.
             * Каждая задача обрабатывает блок строк.
             */
            int rowsPerTask = Math.max(1, (height + threads - 1) / threads);
            List<Future<?>> futures = new ArrayList<>();

            for (int rowStart = 0; rowStart < height; rowStart += rowsPerTask) {
                final int startRow = rowStart;
                final int endRow = Math.min(height, rowStart + rowsPerTask);

                futures.add(pool.submit(() -> {
                    for (int y = startRow; y < endRow; y++) {
                        /*
                         * Мнимая часть ci для текущей строки.
                         * y = 0 считается верхней строкой, поэтому инвертируем ось Y.
                         */
                        double ci = centerY
                                + (((height - 1 - y) - height / 2.0) * spanY / height);

                        boolean[] row = inside[y];
                        long localInside = 0;

                        for (int x = 0; x < width; x++) {
                            double cr = crValues[x];

                            if (isInsideMandelbrot(cr, ci, maxIterations)) {
                                row[x] = true;
                                localInside++;
                            }
                        }

                        insideCount.addAndGet(localInside);
                    }
                }));
            }

            // Ждём завершения всех потоков.
            for (Future<?> future : futures) {
                future.get();
            }

        } finally {
            pool.shutdown();

            if (!pool.awaitTermination(1, TimeUnit.MINUTES)) {
                pool.shutdownNow();
            }
        }

        return new Result(inside, insideCount.get(), threads);
    }

    private static boolean isInsideMandelbrot(
            double cr,
            double ci,
            int maxIterations
    ) {
        double zr = 0.0;
        double zi = 0.0;

        for (int i = 0; i < maxIterations; i++) {
            double zr2 = zr * zr;
            double zi2 = zi * zi;

            double newZr = zr2 - zi2 + cr;
            double newZi = 2.0 * zr * zi + ci;

            zr = newZr;
            zi = newZi;

            if (zr * zr + zi * zi > 4.0) {
                return false;
            }
        }

        return true;
    }
}
